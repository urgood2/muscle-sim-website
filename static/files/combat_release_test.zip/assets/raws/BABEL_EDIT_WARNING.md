Warning regarding BabelEdit

SOmetimes data from json files will randomly vanish.
Make sure this hasn't happened when using babel edit and committing to git.