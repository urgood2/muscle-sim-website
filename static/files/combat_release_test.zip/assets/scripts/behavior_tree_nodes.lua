-- IsFoodInInventory node
Node_IsFoodInInventory = {}

Node_IsFoodInInventory["OnStart"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [IsFoodInInventory] - OnStart started")
    return NodeStatus.RUNNING -- Lua nodes need to return running for OnStart
end

Node_IsFoodInInventory["OnRunning"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [IsFoodInInventory] - OnRunning started")

    local inventory = getInventory(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [IsFoodInInventory] - Got inventory")
    if (inventory:empty()) then
        debug("[Lua]: " .. BTContext.contextID .. ": [IsFoodInInventory] - Inventory is empty")
        return NodeStatus.FAILURE
    end
    
    debug("[Lua]: " .. BTContext.contextID .. ": [IsFoodInInventory] - Inventory not empty - searching...")
    for i = 1, inventory:size(), 1 do
        local food = inventory[i]
        if (isEdible(food)) then
            debug("[Lua]: " .. BTContext.contextID .. ": [IsFoodInInventory] - Edible food found.")
            return NodeStatus.SUCCESS
        end
    end
    return NodeStatus.FAILURE
end

Node_IsFoodInInventory["OnHalted"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [IsFoodInInventory] - OnHalted started")
end

-- PutEnvironmentFoodOnStack node
Node_PutEnvironmentFoodOnStack = {}

Node_PutEnvironmentFoodOnStack["OnStart"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [PutEnvironmentFoodOnStack] - OnStart started")
    return NodeStatus.RUNNING -- Lua nodes need to return running for OnStart
end

Node_PutEnvironmentFoodOnStack["OnRunning"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [PutEnvironmentFoodOnStack] - OnRunning started")
    
    -- find food from the environment (how to distinguish items in inventory?)
    local stack = getEdibleEntityStack(5)
    -- make a list (up to five) and place in context with the name node_params.PutEnvironmentFoodOnStack.Out.stack_result_variable
    
    if (#stack > 0) then
        putStackInContext(stack, BTContext, node_params.PutEnvironmentFoodOnStack.Out.stack_result_variable)
        return NodeStatus.SUCCESS
    end
    
    return NodeStatus.FAILURE
    
end

Node_PutEnvironmentFoodOnStack["OnHalted"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [PutEnvironmentFoodOnStack] - OnHalted started")
end

-- TryClaimObject node
Node_TryClaimObject = {}

Node_TryClaimObject["OnStart"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [TryClaimObject] - OnStart started")
    return NodeStatus.RUNNING -- Lua nodes need to return running for OnStart
end

Node_TryClaimObject["OnRunning"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [TryClaimObject] - OnRunning started")
    local variant = retrieveVariableFromContext(node_params.TryClaimObject.In.required_blackboard_key, BTContext)
    local result = markItemAsClaimed(variant, BTContext)
    
    if (result) then 
        debug("[Lua]: " .. BTContext.contextID .. ": Item claimed.")
        return NodeStatus.SUCCESS
    end
    return NodeStatus.FAILURE
end

Node_TryClaimObject["OnHalted"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [TryClaimObject] - OnHalted started")
end

-- FindPathAndGoToObject node
Node_FindPathAndGoToObject = {}

Node_FindPathAndGoToObject["OnStart"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - OnStart started")
    return NodeStatus.RUNNING -- Lua nodes need to return running for OnStart
end

-- Declare the path variable as a global variable
local path = nil

Node_FindPathAndGoToObject["OnRunning"] = function(entity)
    
    debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - OnRunning started")
    -- how to store path status in context?
    
    -- * first query if path is already stored in context
    local target_entity = retrieveEntityFromContext(node_params.FindPathAndGoToObject.In.required_blackboard_key, BTContext)
    
    -- check that the entity currently has a taskDoerComponent (to make sure the task hasn't been canceled or moved)
    if (entityHasTaskDoerComponent(entity) == false) then
        debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - Entity does not have a taskDoerComponent, returning failure.")
        return NodeStatus.FAILURE
    end
    
    -- print value of entity
    debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - Entity: " .. entity)
    
    -- print value of target_entity
    debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - Target entity: " .. target_entity)
    
    -- use std::get to retrieve the path from the variant
    
    -- check if the context contains a variable with the name of the stored path variable FindPathAndGoToObject.In.stored_path_variable
    
    
    if (path == nil) then
        path = retrievePathFromContextAsTable(node_params.FindPathAndGoToObject.In.stored_path_variable, BTContext, getLuaStateForEntity(entity))
    end 
    
    if (path ~= nil) then
        
        -- path is already stored in context
        debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - Path already stored in context.")
        -- get location of current entity
        local entity_location = getLocation(entity, getLuaStateForEntity(entity))
        -- get the last index node from the path
        local next_jump_point = path[#path] -- path is a vector of std::pair<int, int>
        -- print the contents of the table "next_jump_point". It holds another table with x and y values
        debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - Next jump point table contents: " .. next_jump_point["x"] .. ", " .. next_jump_point["y"])
        -- print the location of the entity
        debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - Entity location: " .. entity_location.x .. ", " .. entity_location.y)
        
        -- if next_jump_point is the last node in path, and the entity location matches next_jump_point, then the entity has reached the target
        if (#path == 1 and entity_location.x == next_jump_point["x"] and entity_location.y == next_jump_point["y"]) then
            -- remove last index node from path
            table.remove(path, #path)
            -- log message to indicate target reached
            debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - Target reached.")
            -- reset path value
            path = nil
            removeVariableFromContext(BTContext, node_params.FindPathAndGoToObject.In.stored_path_variable);
            -- return success
            return NodeStatus.SUCCESS
        end
        
        -- if the entity location does not match next_jump_point, move the current location towards next_jump_point by one tile
        if (entity_location.x ~= next_jump_point["x"] or entity_location.y ~= next_jump_point["y"]) then
            -- move towards next_jump_point
            moveEntityTowards(entity, next_jump_point["x"], next_jump_point["y"]) 
            executeActivity(entity, "WALK", 1) -- 1 is the number of ticks this activity is supposed to have been performed by the entity. Refer to activity.json
            -- return running
            return NodeStatus.RUNNING
        else
            -- get the next node in the path and move the entity towards it
            local next_node = path[#path - 1]
            moveEntityTowards(entity, next_node["x"], next_node["y"])
            executeActivity(entity, "WALK", 1) -- 1 is the number of ticks this activity is supposed to have been performed by the entity. Refer to activity.json
            -- remove last index node from path
            table.remove(path, #path)
            -- return running
            return NodeStatus.RUNNING
        end
    else 
        
        -- path is not in context
        debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - Path not stored in context, finding new path.")
        -- get location of current entity
        local entity_location = getLocation(entity, getLuaStateForEntity(entity))
        -- * get location of target entity
        local target_location = getLocation(target_entity, getLuaStateForEntity(entity))
        -- print the values of entity_location and target_location
        debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - Entity location: " .. entity_location.x .. ", " .. entity_location.y)
        debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - Target location: " .. target_location.x .. ", " .. target_location.y)
        
        -- check if the entity and target are on the same tile
        if (entity_location.x == target_location.x and entity_location.y == target_location.y) then
            -- log message to indicate target reached
            debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - Target reached.")
            -- return success
            return NodeStatus.SUCCESS
        end
        
        -- find path from location to target !fudge::Coord uses first for x, second for y
        local newPath = getPathToForLuaUse(entity_location.x, entity_location.y, target_location.x, target_location.y)
        -- * store path in context
        putVariableInContext(newPath, BTContext, node_params.FindPathAndGoToObject.In.stored_path_variable)
        -- !check that the path is not empty (which means there is no possible path to the target)
        if (newPath:size() == 0) then
            -- log message that no path was found
            error("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - No path found.")
            -- return failure
            return NodeStatus.FAILURE
        end
        
        -- log message saying that a path has been found
        debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - Path found.")
        -- print the contents of the table "path"
        debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - Path table contents:")
        
        return NodeStatus.RUNNING -- let the pathfinder continue on the next tick
    end
end

Node_FindPathAndGoToObject["OnHalted"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [FindPathAndGoToObject] - OnHalted started")
end

-- PickUpFood node
Node_PickUpItem = {}

Node_PickUpItem["OnStart"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [PickUpItem] - OnStart started")
    return NodeStatus.RUNNING -- Lua nodes need to return running for OnStart
end

Node_PickUpItem["OnRunning"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [PickUpItem] - OnRunning started")
    
    -- retrieve the target object from the context - "required_blackboard_key" is the name of the variable in the context
    local target_object = retrieveVariableFromContext(node_params.PickUpItem.In.required_blackboard_key, BTContext)
    
    -- call the placeInInventory() function to place the target object in the entity's inventory
    local result = placeInInventory(target_object, entity)
    
    if (result == false) then
        -- message to say item could not be picked up
        -- debug("[Lua]: " .. BTContext.contextID .. ": [PickUpFood] - Item could not be picked up.")
        return NodeStatus.FAILURE
    else
        -- message to say item picked up successfully
        -- debug("[Lua]: " .. BTContext.contextID .. ": [PickUpFood] - Item picked up successfully.")
        return NodeStatus.SUCCESS
    end
end

Node_PickUpItem["OnHalted"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [PickUpItem] - OnHalted started")
end

-- EatFromInventory node
Node_EatFromInventory = {}

Node_EatFromInventory["OnStart"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [EatFromInventory] - OnStart started")
    return NodeStatus.RUNNING -- Lua nodes need to return running for OnStart
end

Node_EatFromInventory["OnRunning"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [EatFromInventory] - OnRunning started")
    
    -- determine if an edible item is in the entity's inventory, and if so, eat it
    local inventory = getInventory(entity)
    
    -- iterate through the inventory
    for i = 1, #inventory do
        -- check if the item is edible
        if (isEdible(inventory[i]) == true) then
            -- try to eat the item
            local eatSucceeded = eatItem(inventory[i], entity)
            -- return success
            if (eatSucceeded == true) then
                return NodeStatus.SUCCESS
            else
                return NodeStatus.FAILURE
            end
        end
    end
    
    -- message: no edible items were found in the inventory
    debug("[Lua]: " .. BTContext.contextID .. ": [EatFromInventory] - No edible items were found in the inventory.")
    return NodeStatus.FAILURE
end

Node_EatFromInventory["OnHalted"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [EatFromInventory] - OnHalted started")
end



-- GoToLocation node
Node_GoToLocation = {}

Node_GoToLocation["OnStart"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [GoToLocation] - OnStart started")
    return NodeStatus.RUNNING -- Lua nodes need to return running for OnStart
end

Node_GoToLocation["OnRunning"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [GoToLocation] - OnRunning started")
    return NodeStatus.SUCCESS
end

Node_GoToLocation["OnHalted"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [GoToLocation] - OnHalted started")
end

-- FindFoodItem node
Node_FindFoodItem = {}

Node_FindFoodItem["OnStart"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [FindFoodItem] - OnStart started")
    return NodeStatus.RUNNING -- Lua nodes need to return running for OnStart
end

Node_FindFoodItem["OnRunning"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [FindFoodItem] - OnRunning started")
    
    -- make generic method (C++) to find a certain type of item? (edible?)
    
    
    
    -- how to return success from this function?
    
    -- return NodeStatus type (bound via sol)
    return NodeStatus.SUCCESS
end

Node_FindFoodItem["OnHalted"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [FindFoodItem] - OnHalted started")
end

-- Node_PlacePlantInContext

Node_PlacePlantInContext = {}

Node_PlacePlantInContext["OnStart"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [PlacePlantInContext] - OnStart started")
    return NodeStatus.RUNNING -- Lua nodes need to return running for OnStart
end

-- TODO needs to get plant from job component and place in "targetObject"
Node_PlacePlantInContext["OnRunning"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [PlacePlantInContext] - OnRunning started")
    
    -- retrieve the target object from the job component and place it in the PlacePlantInContext.out.context_result_variable value
    
    --TODO make hook for accessing job component 
    -- local taskComponent = getTaskComponent(entity)
    
    -- -- todo get plant from task component, and place in context
    -- local targetPlant = taskComponent.targetEntity
    
    local targetPlant = getTaskTargetEntity(entity)
    local taskEntity = getTaskAssignedToEntity(entity)
    
    -- print the value of targetPlant, in addition to the task number
    debug("[Lua]: " .. BTContext.contextID .. ": [PlacePlantInContext] - targetPlant: " .. targetPlant .. ", taskEntity: " .. taskEntity)
    
    --TODO make sure target plant is removed from the registry and from the tile it belongs to
    
    -- check that targetPlant doesn't equal NULL_ENTITY
    if (isEntityNull(targetPlant)) then
        error("[Lua]: " .. BTContext.contextID .. ": [PlacePlantInContext] - targetPlant is NULL_ENTITY")
        return NodeStatus.FAILURE
    end
    
    putVariableInContext(targetPlant, BTContext, node_params.PlacePlantInContext.Out.context_result_variable)
    
    -- try accessing the variable and printing its value for debug
    local retrievedPlant = retrieveVariableFromContext(node_params.PlacePlantInContext.Out.context_result_variable, BTContext)
    debug("[Lua]: " .. BTContext.contextID .. ": [PlacePlantInContext] - retrievedPlant: " .. retrievedPlant)
    
    return NodeStatus.SUCCESS

end

Node_PlacePlantInContext["OnHalted"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [PlacePlantInContext] - OnHalted started")
end

-- Node_HarvestPlant

Node_HarvestPlant = {}

Node_HarvestPlant["OnStart"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [HarvestPlant] - OnStart started")
    return NodeStatus.RUNNING -- Lua nodes need to return running for OnStart
end

-- TODO needs to use input variable "targetobject"
Node_HarvestPlant["OnRunning"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [HarvestPlant] - OnRunning started")
    --TODO make hook for harvesting task object (provided it's next to the tile)
    
    
    -- retrieve the target object from the context - "required_blackboard_key" is the name of the variable in the context
    local target_object = retrieveVariableFromContext(node_params.HarvestPlant.In.required_blackboard_key, BTContext)
    
    -- log value of target_object
    debug("[Lua]: " .. BTContext.contextID .. ": [HarvestPlant] - got target_object: " .. target_object)
    
    -- call the placeInInventory() function to place the target object in the entity's inventory
    local result = harvestPlant(target_object, entity)
    
    if (result == false) then
        -- message to say item could not be picked up
        -- debug("[Lua]: " .. BTContext.contextID .. ": [HarvestPlant] - Item could not be harvested.")
        return NodeStatus.FAILURE
    else
        -- message to say item picked up successfully
        -- debug("[Lua]: " .. BTContext.contextID .. ": [HarvestPlant] - Item harvested successfully.")
        
        -- since it succeeded, update exp
        executeActivity(entity, "HARVEST", 1) -- 1 is the number of ticks this activity is supposed to have been performed by the entity. Refer to activity.json
        
        -- set the task to be completed
        setTaskCompletedStatus(entity, true)
        
        return NodeStatus.SUCCESS
    end
end

Node_HarvestPlant["OnHalted"] = function(entity)
    debug("[Lua]: " .. BTContext.contextID .. ": [HarvestPlant] - OnHalted started")
end