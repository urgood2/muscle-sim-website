--TODO make seperate triggers for profession level up and muscle level up


TriggerLevelUp = function(entity, bodyPartName)
    --TODO add level up logic, such as setting animations, special effects, etc.
    --TODO make a global lua state for level up system?
    
    debug("[Lua]: [GlobalSystemSharedLuaState]: [TriggerLevelUp]:" .. "Level up trigger called for entity " .. entity)
    
    queueAnimation(entity, "level_up_animation")
    -- toast.levelup
    local message = getTranslatedStringAndFormat("toast.levelup", getEntityName(entity), bodyPartName)
    queueInfoToastMessage(message)
end
    
TriggerLevelUpProfession = function(entity, professionName)
    --TODO add level up logic, such as setting animations, special effects, etc.
    --TODO make a global lua state for level up system?
    
    debug("[Lua]: [GlobalSystemSharedLuaState]: [TriggerLevelUpProfession]:" .. "Level up trigger called for entity " .. entity)
    
    queueAnimation(entity, "level_up_animation")
    -- toast.levelup_profession
    local message = getTranslatedStringAndFormat("toast.levelup_profession", getEntityName(entity), professionName)
    queueInfoToastMessage(message)
end