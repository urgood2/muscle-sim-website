-- A value "M" is assumed to exist in the global scope.
-- This value is the sum of the muscle levels of each body part, weighted by the body part's mass. It is the basis of all stat calculations.
-- TODO create a method to calculate M from the body parts

-- Returns a value between 0 and 100
Stat_GetEvasion = function()
    return 100 * (M / (M + 100))
end

-- Returns a value between 0 and 100
Stat_GetAccuracy = function()
    return 100 * (100 / (M + 100))
end

-- Returns a value that increases linearly with muscle growth
Stat_GetEndurance = function()
    return 5 * M
end

-- Returns a value that increases linearly with muscle growth
Stat_GetDefense = function()
    return 1.5 * M
end

-- Returns a value that increases linearly with muscle growth
Stat_GetHealthPoints = function()
    return 10 * M
end