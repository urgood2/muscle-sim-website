-- global variables
work_bt_to_execute = nil -- store bt name to execute
work_bt_started = false -- store whether bt has started

-- utility functions
Utility = {}

Utility["getBTForTask"] = function(taskID)
    local taskString = getStringForTaskID(taskID) -- need to make method in cpp
    return behaviorTreeMap[taskString] -- this should be registered from cpp code
end


--Idling state
State_Idle = {}

State_Idle["Enter"] = function(entity)
    
end

State_Idle["Update"] = function(entity)
    debug("[Lua]: " .. FSMContext.logHeader .. "Currently idling")
end

State_Idle["Exit"] = function(entity)

end

State_Idle["Utility"] = function(entity)
    -- This method is called to determine whether the entity should switch to this state. It returns a value between 0 and 1, where 0 means the entity should not switch to this state, and 1 means the entity should switch to this state. This value is compared with the values returned by the other states' utility methods, and the state with the highest value is chosen.
    
    --TODO idle utiity logic
    
    return 0.5

end

--Eat state

State_Eat = {}

State_Eat["Enter"] = function(entity)
    print("[Lua]: Function body goes here")
end

State_Eat["Update"] = function(entity)

end

State_Eat["Exit"] = function(entity)

end

State_Eat["Utility"] = function(entity)
    
    -- TODO eat utility logic (ie when hungry)
    return 0.1
end


-- fight state
State_Fight = {}

State_Fight["Enter"] = function(entity)

end

State_Fight["Update"] = function(entity)

end

State_Fight["Exit"] = function(entity)

end

State_Fight["Utility"] = function(entity)
    --TODO fight utility logic
    
    return 0.1
end

-- working state (executing tasks)

State_DoWork = {}

State_DoWork["Enter"] = function()
    
    -- work_bt_to_execute = getBTForTask(taskID)
    -- store the right BT for the task type at hand in a variable
    -- set entity working status to true?
end

State_DoWork["Update"] = function(entity)
    
    --TODO intialize fsm lua state with appropriate bindings
    --TODO use bt_config.json to know which trees to store where, with what ID
    
    -- debug message to show that the bt is being ticked
    
    
    local task = getCurrentTask(entity)
    
    -- if the task is null, then we have no task to execute, so we should return to the idle state
    
    if (isEntityNull(task))
    then
        debug("[Lua]: " .. FSMContext.logHeader .. "No task to execute, returning to idle state")
        utilitizeToNewState(entity)
        return
    end
    
    local bt = getBTForTask(task, entity)
    
    -- check if the bt is null
    if (bt == nil)
    then
        debug("[Lua]: " .. FSMContext.logHeader .. "BT is null, moving out of working state")
        utilitizeToNewState(entity)
        return
    end
    
    local status = bt:tickRoot()
    debug("[Lua]: " .. FSMContext.logHeader .. "Ticking BT")
    
    if (status == NodeStatus.SUCCESS) 
    then
        --TODO use context id in logging message
        debug("[Lua]: " .. FSMContext.logHeader .. "Removing task")
        removeTask(task, entity)
        --TODO maybe don't remove task here, but let the task manager do it?
        
        debug("[Lua]: " .. FSMContext.logHeader .. "BT returned success")
        utilitizeToNewState(entity) -- bt does not need to be reset (automatic)
    elseif (status == NodeStatus.FAILURE)
    then
        error("[Lua]: " .. FSMContext.logHeader .. "BT returned failure")
        removeTaskDesignationFromEntity(entity)
        utilitizeToNewState(entity)
    end
    
end

State_DoWork["Exit"] = function(entity)
    -- if bt has finished, no cleanup needed
    -- if bt hasn't finished, save it for later? in a prev_bt var?
end

State_DoWork["Utility"] = function(entity)
    -- Entities don't utilize automatically to this state, they need to be told to do so by the work manager (and only when there is a task
    
    return 0
end