-- This file contains behavior tree parameters for LuaActionNodes.
-- Since the parameters of LuaActionNodes can't be specified directly in the 
-- script, we have to define them in this file.
-- In addition, since with general-purpose nodes, parameters can be different in different trees or even within the same tree (for istance, "PopFromStack" could be used multiple times and require a different stack variable be used for each one), we would ordinarily have to define the parameters for each tree separately. This will make things too complicated, so we will instead define set parameters for each type of LuaActionNode in this file. The assumption is that LuaActionNodes with the same names will have the same parameters every time.
-- TODO implement a way to customize parameters on a tree-by-tree basis.
-- The "In" tables contain required blackboard key inputs.
-- The "Out" tables contain entries added to the blackboard by the node.

node_params = {
    
    PutEnvironmentFoodOnStack = {
        In = {
            required_blackboard_key = "stack_variable"
        },
        Out = {
            stack_result_variable = "envFoodStack"
        }
    },
    
    TryClaimObject = {
        In = {
            required_blackboard_key = "targetObject"
        }
    },
    
    FindPathAndGoToObject = {
        In = {
            required_blackboard_key = "targetObject",
            stored_path_variable = "currentPath"
        }
    },
    
    PickUpItem = {
        In = {
            required_blackboard_key = "targetObject"
        }
    },
    
    EatFromInventory = {
        In = {
            required_blackboard_key = "targetObject"
        }
    },
    
    PlacePlantInContext = {
        Out = {
            context_result_variable = "targetObject"
        }
    },
    
    HarvestPlant = {
        In = {
            required_blackboard_key = "targetObject"
        }
    }
    -- Add more nodes and their parameters as needed
}