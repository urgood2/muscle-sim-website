
-- make a function to reset the behavior tree context tied to this lua state

utils = {}

utils.resetBTContext = function()
    
    -- "BTContext" is a global variable (for this lua state) that is set in the C++ code
    resetBTCustomContext(BTContext)
    
    
end